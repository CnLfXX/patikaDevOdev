
function NameChanger(id,userHTML){
    const changer = document.querySelector(`#${id}`)
    changer.innerHTML= userHTML
    
}
if(NameChanger == null && undefined){
    console.log("isim yazmadın")
}

NameChanger('myName',prompt('please enter your name'))





function showTime(){

  const Clock = document.querySelector('#myClock')
  const exactClock = new Date();
  const year = exactClock.getFullYear().toString().padStart(4,'0')
  const month = exactClock.getMonth().toString().padStart(2,'0')
  const hours = exactClock.getHours().toString().padStart(2,'0')
  const minute =exactClock.getMinutes().toString().padStart(2,'0')
  const second =exactClock.getSeconds().toString().padStart(2,'0')
  



const days = ["Pazar", "Pazartesi", "Sali", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"]
const day =days[exactClock.getDay()]

Clock.textContent=`${hours}:${minute}:${second}, ${day}, ${month},${year}`
console.log(exactClock)
setInterval(showTime,1000)
}
window.onload = () => document.querySelector('#myClock') && showTime();



